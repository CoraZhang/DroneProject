SELECT 
    COUNT(*)
FROM
spectrum.fcclicensesample;
    
	

